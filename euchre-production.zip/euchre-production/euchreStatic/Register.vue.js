var registerTemplate = `
<div class="col-lg-8 col-lg-offset-2 col-md-8 col-md-offset-2" style="margin-top: 0%;" >
  <h1 style="text-align: center;">Register</h1>
  <div style="width: 40%; margin-left: 30%; border-style: solid; border-radius: 10px; padding-left: 15px; padding-right: 15px;" v-show="!done">
	<h5>Full Name</h5>
	<input  class="form-control" placeholder="Enter name" v-model="name" />
	<h5>Username</h5>
	<input  class="form-control" placeholder="Enter username" v-model="username" v-bind:style="{color: usernamecolor}"/>
	<h5>Email</h5>
	<input  class="form-control" placeholder="Enter email" v-model="email"/>
	<h5>Password</h5>
	<input class="form-control" type="password" placeholder="Enter password" v-model="password" :style="{color: passwordcolor}"/>
	<h5>Confirm Password</h5>
	<input class="form-control" type="password" placeholder="Enter password" v-model="password2" :style="{color: passwordcolor}"/>
	<br />
	<input class="" type="checkbox" v-model="agreed" /> I have read and agree to the Terms and Conditions
    <br />
	<br />
	<button class="btn btn-primary" v-on:click="checkData()">Register</button>
	<br />
	<br />
  </div>
  <h2 v-show="done">Thank you for signing up!</h2>
  <h4 v-show="done">An email has been sent to your address prompting you to verify your account. Once you've verified, you may login and begin using it.</h4>
</div>
`;


var register = {
  template: registerTemplate,
  data: function(){
    return {
		name: null,
		username: null,
		email: null,
		password: null,
		password2: null,
		agreed: false,
		usernamecolor: "black",
		passwordcolor: "black",
		done: false
    }
  },
  methods: {
	 checkData: function(){
      var fields = ['name', 'username', 'email', 'password', 'password2', 'agreed'];
	  var filled = true;
	  	 if (!this.agreed){
		  alert("You must accept the terms and conditions in order to register");
		  return;
	  }
	  for (var field of fields){
		  if (!this[field]){
			  alert("Please fill out all fields.");
			  return;
		  }
	  }
	  if (this.passwordcolor == "red"){
		  alert("Passwords must match");
		  return;
	  }
	  if (this.usernamecolor == "red"){
		  alert("This username is already taken");
		  return;
	  }
	  var payload = {
		name: this.name,
		username: this.username,
		password: this.password,
		email: this.email
	  };
	  var _this = this;
	  axios.post(`https://${this.$parent.baseUrl}/register`, payload).then(function(result){
		  _this.done = true;
		 // _this.$root.$router.push({path: '/login'});
	  }).catch(function(err){
		  alert("Failed");
	  });
	  console.log("ok");
    }
  },
  watch: {
	  username: function(){
		  var _this = this;
		  axios.get(`https://${this.$parent.baseUrl}/uniqueUsername/${this.username}`).then(function(result){
			  _this.usernamecolor = "green";
		  }).catch(function(err){
			  _this.usernamecolor = "red";
		  });
	  },
	  password: function(){
		  if (this.password == this.password2){
			  this.passwordcolor = "green";
			  return;
		  }
		  this.passwordcolor = "red";
	  },
	  password2: function(){
		  if (this.password == this.password2){
			  this.passwordcolor = "green";
			  return;
		  }
		  this.passwordcolor = "red";
	  }
  }
}