
var router = new VueRouter({
  routes: [
    {path: "/", component: home2}, 
	{path:"/game", component: game}, 
	{path: "/start", component: start},
	{path: "/register", component: register},
	{path: "/login", component: login},
	{path: "/verified", component: verified}
  ],
  base: "/"
});
Vue.use(VueRouter);
var app = new Vue({
  el: "#appy",
  router: router,
  data: function(){
    return {
      connection: null,
      gameKey: null,
	  fromQueue: false,
      playerNames: {north: "", south: "", east: "", west: ""},
      team: null,
      myName: null,
	  token: null,
      spade: "resources/spade.png",
      club: "resources/club.png",
      diamond: "resources/diamond.png",
      heart: "resources/heart.png",
	  man: "resources/man.png",
	  x: "resources/x.png",
	  baseUrl: "euchre.ftp.sh"
    }
  },
  methods: {
    incomingMessage: function(msg){
      console.log(msg);
	  var newArray = this.$children.filter(child => child.$children.length > 0);
      for(var child of this.$children){
		if (child.incomingMessage){
			child.incomingMessage(JSON.parse(msg.data));
		}
      }
    },
	logout: function(){
		this.token = null;
		window.$cookies.remove('token');
	},
    sendMessage: function(json){
      this.connection.send(JSON.stringify(json));
    }
  },
  created: function(){
    this.connection = new WebSocket("wss://" + this.baseUrl + "/");
    this.connection.onmessage = this.incomingMessage;
    console.log(this.$children);
	if (window.$cookies.get("token")){
		this.token = window.$cookies.get("token");
		var _this = this;
		axios.get("https://" + this.baseUrl + "/name/" + this.token).then(function(res){
			_this.myName = res.data;
		});
	}
  }
});
//window.$cookies.set('test', '123');
