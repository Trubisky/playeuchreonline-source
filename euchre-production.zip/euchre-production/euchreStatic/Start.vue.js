var startTemplate = `
<div class="col-lg-8 col-lg-offset-2 col-md-8 col-md-offset-2" style="text-align: center;">
  <h1 v-show="!$root.fromQueue">Your game code is: {{$root.gameKey}}</h1>
  <h1 v-show="$root.fromQueue">New Quick Match Game</h1>
  <input class="form-control" style="width: 40%; margin-left: 30%;" v-model="myName" v-show="!pickedName" placeholder="Your Name"/>
  <button class="btn btn-primary" style="margin-top: 15px;" v-show="!pickedName" v-on:click="pickName">Join Game</button>
  <h4 v-show="pickedName">Select a team</h4>
  <div class="row" style="width: 40%; margin-left: 30%;" v-show="pickedName">
	<div class="col-xs-6" style="padding: 0 10px 0 10px;">
		<h4 style="text-align: center;">North / South</h4>
		<button style="width: 100%; height: 15%;" class="btn btn-primary" v-on:click="joinTeam('north')" v-bind:disabled="($root.playerNames.north != 'Open' || pickedTeam) ? true : false">North ({{$root.playerNames.north}})</button>
		<button style="width: 100%; height: 15%;" class="btn btn-primary" v-on:click="joinTeam('south')" v-bind:disabled="($root.playerNames.south != 'Open' || pickedTeam) ? true : false">South ({{$root.playerNames.south}})</button>
	</div>
	<div class="col-xs-6" style="padding: 0 10px 0 10px;">
		<h4 style="text-align: center;">East / West</h4>
		<button style="width: 100%; height: 15%;" class="btn btn-primary" v-on:click="joinTeam('east')" v-bind:disabled="($root.playerNames.east != 'Open' || pickedTeam) ? true : false">East ({{$root.playerNames.east}})</button>
		<button style="width: 100%; height: 15%;" class="btn btn-primary" v-on:click="joinTeam('west')" v-bind:disabled="($root.playerNames.west != 'Open' || pickedTeam) ? true : false">West ({{$root.playerNames.west}})</button>
	</div>
  </div>
  <h3 v-show="countdown">All players have now joined a team; starting game in {{countdown}} seconds</h3>
</div>
`;


var start = {
  template: startTemplate,
  data: function(){
    return {
      myName: null,
      pickedName: false,
      pickedTeam: false,
      countdown: 0
    }
  },
  methods: {
    incomingMessage: function(msg){
      switch(msg.action){
        case "getPlayersResult":
          console.log(msg.players);
          this.$root.playerNames = msg.players;
        case "gameCountdownMessage":
          this.countdown = msg.time;
          if (msg.time == 0){
            this.$root.$router.push({path: '/game'});
          }
      }
    },
    pickName: function(){
      if (this.myName){
        this.pickedName = true;
      }
    },
    joinTeam: function(teamName){
      this.pickedTeam = true;
      this.$root.team = teamName;
      this.$root.myName = this.myName;
      this.$root.sendMessage({action: "joinTeam", key: this.$root.gameKey, team: teamName, name: this.myName, token: this.$root.token});
	  if (!this.$root.token){
		  this.myName+=" - Guest";
		  this.$root.myName+=" - Guest";
	  }
    }
  },
  mounted: function(){
    this.$root.sendMessage({action: "getPlayers", key: this.$root.gameKey});
	if (this.$root.token){
		this.myName = this.$root.myName;
		this.pickName();
	}
    console.log(this.$root.gameKey)
  }
}