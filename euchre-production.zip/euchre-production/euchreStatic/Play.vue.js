var playTemplate = `
<router-view>

</router-view>
`;


var play = {
  template: playTemplate,
  data: function(){
    return{
		
    }
  }
}