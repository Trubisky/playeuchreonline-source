var verifiedTemplate = `
	<div>
	<h1 style="text-align: center;">Thank you for verifying your email!</h1>
	<h4 style="text-align: center; color: white;">You may now login and use your new account</h4>
	</div>
`;


var verified = {
  template: verifiedTemplate,
  data: function(){
    return{
		
    }
  }
} 