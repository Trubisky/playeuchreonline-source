var home2Template = `
<div class="row">
	<div class="col-xs-8" style="margin-top: 8%;">
		<div class="col-sm-4 col-xs-12" v-show="!inQueue">
			<h1 style="text-align: center;">Public Lobby</h1>
			<h3 style="text-align: center;">Quick Match</h3>
			<button class="btn btn-primary" style="width: 30%; margin-left: 35%;" v-on:click="joinQueue">Join Queue</button>
			<h3 style="text-align: center; margin-top: 50%;">Ranked Match</h3>
			<button disabled class="btn btn-primary" style="width: 30%; margin-left: 35%;">Coming Soon</button>
		</div>
		<div class="col-sm-4 col-xs-12" v-show="!inQueue">
			<img src="resources/logo.png" style="width: 100%; height: auto;"/>
		</div>
		<div class="col-sm-4 col-xs-12" v-show="!inQueue">
			<h1 style="text-align: center;">Private Lobby</h1>
			<h3 style="text-align: center;">Create Custom Game</h3>
			<button class="btn btn-primary" style="width: 30%; margin-left: 35%;" v-on:click="startGame">New Game</button>
			<h3 style="text-align: center; margin-top: 50%;">Join Custom Game</h3>
			<input style="width: 40%; margin-left: 30%;" class="form-control" placeholder="Game Code" v-model="keyInput" v-bind:style="{color: joinColor}"/>
			<button class="btn btn-primary" style="width: 30%; margin-left: 35%;" v-on:click="joinGame">Join</button>
		</div>
		<div class="col-sm-4 col-sm-offset-4 col-xs-12" v-show="inQueue">
			<h1 style="text-align: center">Searching for a match</h1>
			<img style="width: 30%; margin-left: 35%; height: auto;" src="resources/loading.gif"/>
			<h4 style="text-align: center;">Players in queue: {{count}}</h4>
		</div>
	</div>
	<div class="col-xs-4">
		<h1 style="text-align: center;">What is Euchre?</h1>
		<p style="text-align: center; padding: 0px 50px 0px 50px; font-size: 20px;">
			Euchre, according to Oxford Languages, is "a card game for two to four players, usually played with the thirty-two highest cards, the aim being to win at least three of the five tricks played". It is immensely popular in the northeastern United States, and its roots can be traced all the way back to the early 1800s. 
			<br /><br />
			This website, Euchre Online, was spawned out of my love for euchre, and my dissatisfaction with available online options. Me and several friends wanted to play during quarantine in 2020, but could find no solution online that was both easy and paywall free.
			<br /><br />
			The game currently features public matchmaking and custom games to be played with friends. Public, ranked euchre is next on the list of features to be developed. Thank you for supporting this site by playing!
		</p>
	</div>
</div>
`;


var home2 = {
  template: home2Template,
  data: function(){
    return{
      keyInput: null,
	  clientKey: null,
	  inQueue: false,
	  count: null,
	  joinColor: "black"
    }
  },
  methods:{
    incomingMessage: function(msg){
      switch(msg.action){
        case "newGameResult":
          console.log(msg.key);
          this.$root.gameKey = msg.key;
		  this.$root.fromQueue = msg.fromQueue;
          this.$root.$router.push({path: '/start'});
          break;
        case "joinGameResult":
          if (msg.result == false){
            var _this = this;
			this.joinColor = "red";
			setTimeout(function(){_this.joinColor = "black";}, 2000);
            return;
          }
          this.$root.gameKey = this.keyInput;
          this.$root.$router.push({path: '/start'});
          break;
		case "playersInQueue":
		  this.count = msg.count;
		  break;
		 
		
      }
    },
    startGame: function(msg){
       this.$root.sendMessage({action: "newGame"});
    },
    joinGame: function(){
      this.$root.sendMessage({action: "joinGame", key: this.keyInput});
    },
	joinQueue: function(){
	  this.inQueue = true;
	  this.$root.sendMessage({action: "joinQueue"});
	}
  }
}