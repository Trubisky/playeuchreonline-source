var loginTemplate = `
<div class="col-lg-8 col-lg-offset-2 col-md-8 col-md-offset-2" style="margin-top: 0%;" >
  <h1 style="text-align: center;">Login</h1>
  <div style="width: 40%; margin-left: 30%; border-style: solid; border-radius: 10px; padding-left: 15px; padding-right: 15px;">
	<h5>Username</h5>
	<input  class="form-control" placeholder="Enter username" v-model="username"/>
	<h5>Password</h5>
	<input  class="form-control" placeholder="Enter password" v-model="password"/>
	<br />
	<button class="btn btn-primary" v-on:click="login()">Login</button>
	<br />
	<br />
  </div>
</div>
`;
var login = {
	template: loginTemplate,
	data: function(){
		return {
			username: null,
			password: null
		}
	},
	methods: {
		login: function(){
			var _this = this;
			axios.post("https://" + this.$root.baseUrl + "/login", {username: this.username, password: this.password}).then(function(res){
				_this.$root.token = res.data;
				window.$cookies.set("token", res.data);
				alert("Successfully logged in");
				axios.get("https://" + _this.$root.baseUrl + "/name/" + res.data).then(function(res2){
					_this.$root.myName = res2.data;
				});
				_this.$root.$router.push({path: '/'});
			}).catch(function(err){
				alert("Invalid username or password");
			});
		}
	}
};