var AWS = require('aws-sdk');
AWS.config.loadFromPath('');
exports.sendVerification = function(email, link){
	var template = `
	<h1>Thank you for signing up with Euchre Online!</h1>
	<p>In order to activate your account, please click the verification link below. After, you'll be able to log in to your account.
	<br />
	<br />
	<a href="${link}">Verify</a>
	<br />
	<br />
	Note: if you are unable to click the link above, you may manually verify by pasting the following link into your browser's address bar: ${link}
	<br />
	<br />
	Copyright John Jusko, 2020.
	</p>
	`;
	var params = {
	  Destination: { /* required */
		CcAddresses: [
		  /* more items */
		],
		ToAddresses: [
		  email
		  /* more items */
		]
	  },
	  Message: { /* required */
		Body: { /* required */
		  Html: {
		   Charset: "UTF-8",
		   Data: template
		  },
		  Text: {
		   Charset: "UTF-8",
		   Data: "TEXT_FORMAT_BODY"
		  }
		 },
		 Subject: {
		  Charset: 'UTF-8',
		  Data: 'Verify your Euchre Online account'
		 }
		},
	  Source: 'admin@playeuchre.online', /* required */
	  ReplyToAddresses: [
		 'jjusko@umich.edu',
		/* more items */
	  ],
	};
	var sendPromise = new AWS.SES({apiVersion: '2010-12-01'}).sendEmail(params).promise();
	return new Promise(function(resolve, reject){
		sendPromise.then(
  function(data) {
    resolve(data.MessageId);
  }).catch(
    function(err) {
    reject(err);
  });
	});
	
}