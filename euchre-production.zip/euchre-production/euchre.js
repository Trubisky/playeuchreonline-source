const express = require('express');
const app = express();
const http = require('http');
const ws = require('ws');
const fs = require('fs');
var mail = require('./mail.js');
const bodyParser = require("body-parser");
var bcrypt = require('bcrypt');
const https = require('https');
const dbFile = "./euchre.db";
const sqlite3 = require("sqlite3").verbose();
const db = new sqlite3.Database(dbFile);
app.use(express.static('euchreStatic'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
var quickQueue = [];
/*
quickQueue object = {client, 
*/
//http.createServer(app).listen(80);


var hserver = http.createServer(app).listen(8000);

//ENDPOINTS and STRAIGHT CONFIG
app.get("/name/:token", async function(req, res){
	var id = await resolveUserId(req.params.token);
	db.get("SELECT NAME FROM USER WHERE ID = ?;", [id], function(err, row){
		if (!row){
			res.send(400);
			return;
		}
		res.send(row.NAME);
		return;
	});
});
app.get("/verify/:token", async function(req, res){
	db.run('UPDATE USER SET ISACTIVE = 1 WHERE EMAILTOKEN LIKE ?;', [req.params.token], function(err){
		console.log("verified user");
		res.redirect("/#/verified");
	});
});
app.post("/register", async function(req, res){
	console.log(req);
  console.log('registering new user');
  //console.log(req);
  var isGenuine = await new Promise(function(resolve, reject){
    db.get('SELECT ID FROM USER WHERE LOWER(USERNAME) LIKE LOWER(?);', [req.body.username], function(err, row){
      if (!row){
        resolve(true);
      }
      else{
        resolve(false);
      }
    })
  });
  if (!isGenuine){
    res.sendStatus(403);
    return;
  }
  var password = await new Promise(function(resolve, reject){
    bcrypt.hash(req.body.password, 10, function(err, hash){
      resolve(hash);
    });
  });
  var token = generateToken(25);
  var emailtoken = generateToken(25);
  console.log(token);
  var success = await new Promise(function(resolve, reject){
	  mail.sendVerification(req.body.email, "https://playeuchre.online/verify/" + emailtoken).then(function(a){
		  resolve(1);
	  }).catch(function(b){
		  resolve(0);
	  });
  });
  if (!success){
	  res.sendStatus(403);
	  return;
  }
  console.log('sent verification email');
  db.run('INSERT INTO USER (NAME, USERNAME, EMAIL, PASSWORD, TOKEN, ISACTIVE, EMAILTOKEN, WINS, LOSSES) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);',
    [req.body.name, req.body.username, req.body.email, password, token, 0, emailtoken, 0, 0],
    function(){
      res.send(token);
    });
});
app.post("/login", async function(req, res){
  console.log('trying login');
  var token = await new Promise(function(resolve, reject){
    db.get("SELECT TOKEN, PASSWORD FROM USER WHERE LOWER(?) LIKE LOWER(USERNAME) AND ISACTIVE = 1;", [req.body.username], function(err, row){
      if (!row){
        resolve("");
        return;
      }
      bcrypt.compare(req.body.password, row.PASSWORD, function(err2, res){
        if (res){
          resolve(row.TOKEN);
          return;
        }
        resolve("");
        return;
      });
    });
  });
  if (token){
    res.send(token);
  }
  else{
    res.sendStatus(401);
  }
}) ;
app.get("/uniqueUsername/:username", async function(req, res){
	db.all("SELECT ID FROM USER WHERE LOWER(?) LIKE LOWER(USERNAME);", [req.params.username], function(err, rows){
		if (!rows[0]){
			res.sendStatus(200);
			return;
		}
		res.sendStatus(403);
		return;
	});
});
function resolveUserId(token){
  if (!token){
    token = "a";
  }
  return new Promise(function(resolve, reject){
    db.get("SELECT ID FROM USER WHERE TOKEN LIKE ?;", [token], function(err, row){
      if (row){
        resolve(row.ID);
        return;
      }
      resolve(0);
      return;
    });
  });
}









//GAME LOGIC


var activeGames = {};
const cards = ["NH", "TH","JH","QH","KH","AH","ND","TD","JD","QD","KD","AD","NS","TS","JS","QS","KS","AS","NC","TC","JC", "QC", "KC", "AC"];
const order = ["north", "east", "south", "west"];
const teammates = {north: "south", south: "north", east: "west", west: "east"};
const match = {
        D: "H",
        H: "D",
        S: "C",
        C: "S"
      }
const server = new ws.Server({
  server: hserver
});
server.on('connection', function connection(client){
  client.on('message', async function incoming(message){
    var data = JSON.parse(message);
    console.log(data);
    switch(data.action){
      case "newGame":
        var gKey = newGame();
        activeGames[gKey].connectedClients.push(client);
        var rData = {action: "newGameResult", key: gKey, fromQueue: false}
        client.send(JSON.stringify(rData));
        break;
      case "getPlayers":
        var rData = {action: "getPlayersResult", players: getPlayers(data.key)};
        client.send(JSON.stringify(rData));
        break;
      case "joinTeam":
		var id = await resolveUserId(data.token);
		console.log(id);
		console.log("joined");
		if (id){
			activeGames[data.key].players[data.team].id = id;
		}
		else{
			data.name = data.name + " - Guest";
		}
        activeGames[data.key].players[data.team].name = data.name;
        activeGames[data.key].players[data.team].client = client;
        var rData = {action: "getPlayersResult", players: getPlayers(data.key)};
        for (var client2 of activeGames[data.key].connectedClients){
            client2.send(JSON.stringify(rData));
        }
        var allReady = true;
        for (var key in activeGames[data.key].players){
          if (!activeGames[data.key].players[key].client){
            allReady = false;
          }
        }
        if (allReady){
          for (var i=10; i>=0; i--){
            var rData = {action: "gameCountdownMessage", time: i};
            for (var client2 of activeGames[data.key].connectedClients){
                client2.send(JSON.stringify(rData));
            }
            await new Promise(function(resolve, reject){
              setTimeout(resolve, 1000);
            });
          }
          runGame(data.key);
        }
        break;
      case "joinGame":
        var rData;
      //  console.log(activeGames[data.key])
        if (activeGames[data.key]){
		  activeGames[data.key].connectedClients.push(client);
          rData = {action: "joinGameResult", result: true};
          client.send(JSON.stringify(rData));
          return;
        }
        rData = {action: "joinGameResult", result: false};
        client.send(JSON.stringify(rData));
        break;
      case "confirmJoin":
        activeGames[data.key].joins++;
        break;
	  case "joinQueue":
		quickQueue.push(client);
		break;
      case "sendPlay":
		if (activeGames[data.key].players[data.team].play == null){
			activeGames[data.key].players[data.team].play = data.play;
		}
		else{
			activeGames[data.key].players[data.team].client.send(JSON.stringify({action: "getHandResult", cards: activeGames[data.key].players[data.team].cards}));
		}
        break;
    }
  });
});
setInterval(quickMatch, 3000);
function quickMatch(){
	for (var i=0; i<quickQueue.length; i++){
		if (quickQueue[i].readyState != 1){
			quickQueue.splice(i, 1);
		}
	}
	for (var client of quickQueue){
		var rData = {action: "playersInQueue", count: quickQueue.length}
		client.send(JSON.stringify(rData));
	}
	if (quickQueue.length >= 4){
		var clients = quickQueue.splice(0, 4);
		var gKey = newGame();
		for (var client of clients){
			activeGames[gKey].connectedClients.push(client);
			var rData = {action: "newGameResult", key: gKey, fromQueue: true}
			client.send(JSON.stringify(rData));
		}
	}
}
function newGame(){
  var key = generateToken(5)
  var nGame = {
    key: key,
    joins: 0,
    turn: 0,
    trump: null,
    calledTrump: null,
    lead: null,
    connectedClients: [],
    flip: null,
    players: {
      north: {
        name: "",
        client: null,
        cards: [],
        play: null,
		id: null,
		out: false
      },
      south: {
        name: "",
        client: null,
        cards: [],
        play: null,
		id: null,
		out: false
      },
      east: {
        name: "",
        client: null,
        cards: [],
        play: null,
		id: null,
		out: false
      },
      west: {
        name: "",
        client: null,
        cards: [],
        play: null,
		id: null,
		out: false
      }
    },
    scores: {
      northsouth: 0, 
      eastwest: 0
    },
    rScores: {
      northsouth: 0, 
      eastwest: 0
    },
    dealer: Math.floor(Math.random()*4),
    dealHand: function(){
      var options = cards.slice();
      this.players.north.cards = [];
      this.players.south.cards = [];
      this.players.east.cards = [];
      this.players.west.cards = [];
      var order = ["north", "south", "east", "west"]
      var lIndex = 0;
      for(var i=0;i<20; i++){
        var chosenCard = options.splice(Math.floor(options.length*Math.random()), 1)[0];
        this.players[order[lIndex]].cards.push(chosenCard);
        lIndex++;
        if (lIndex==4){
          lIndex=0;
        }
      }
      this.flip = options.splice(Math.floor(options.length*Math.random()), 1)[0];
    },
    advanceDealer: function(){
      this.dealer++;
      if (this.dealer == 4){
        this.dealer = 0;
      }
    },
    advanceTurn: function(){
      this.turn++;
      if (this.turn == 4){
        this.turn = 0;
      }
    }
  }
  activeGames[key] = nGame;
  return key;
}
function getPlayers(key){
  console.log(key);
  var northName = activeGames[key].players.north.name ? activeGames[key].players.north.name : "Open";
  var southName = activeGames[key].players.south.name ? activeGames[key].players.south.name : "Open";
  var eastName = activeGames[key].players.east.name ? activeGames[key].players.east.name : "Open";
  var westName = activeGames[key].players.west.name ? activeGames[key].players.west.name : "Open";
  var nObject = {north:  northName, south: southName, west: westName, east: eastName};
  return nObject
}
function generateToken(length){
  while (true){
	var tString = "";
	var usableTokenCharacters = "abcdefghijklmnopqrstuvwxyz";
	for (var i=0; i<length; i++){
		tString+=usableTokenCharacters[Math.floor(Math.random() * usableTokenCharacters.length)];
	} 
	if (!activeGames[tString]){
		return tString;
	}
  }
}
async function runGame(key){
  var game = activeGames[key];
  while (true){
    await sleep(500);
    console.log(game.joins);
    if (game.joins == 4){
      break;
    }
  }
  console.log("all players joined");
  while(true){
  game.dealHand();
  for (var player of ["north", "south", "west", "east"]){
    game.players[player].client.send(JSON.stringify({action: "getHandResult", cards: game.players[player].cards}));
    game.players[player].client.send(JSON.stringify({action: "getDealerResult", dealer: order[game.dealer]}));
	game.players[player].client.send(JSON.stringify({action: "getFlipCard", card: game.flip}));
  }
  game.turn = game.dealer + 1;
  if (game.turn == 4){
    game.turn = 0;
  }
  var someoneCalled = false;
  for (var i=0; i<4; i++){
    for (var player of ["north", "south", "west", "east"]){
      game.players[player].client.send(JSON.stringify({action: "getTurnResult", turn: order[game.turn]}));
    } 
	game.players[order[game.turn]].play = null;
    game.players[order[game.turn]].client.send(JSON.stringify({action: "pickTrump", card: game.flip}));
    while (true){
      await sleep(300);
      if (game.players[order[game.turn]].play == "pass"){
        game.advanceTurn();
        break;
      }
      else if(game.players[order[game.turn]].play == "call"){
        someoneCalled = true;
        game.trump = game.flip.split("")[1];
        for (var player of ["north", "south", "west", "east"]){
          game.players[player].client.send(JSON.stringify({action: "getTrumpResult", trump: game.trump, called: order[game.turn]}));
          game.calledTrump = order[game.turn];
        } 
        break;
      }
    }
    if (someoneCalled == true){
      game.players[order[game.dealer]].play = null;
      for (var player of ["north", "south", "west", "east"]){
        game.players[player].client.send(JSON.stringify({action: "getTurnResult", turn: order[game.dealer]}));
      } 
      game.players[order[game.dealer]].client.send(JSON.stringify({action: "replaceCard", card: game.flip}));
      while (true){
        await sleep(300);
        if (game.players[order[game.dealer]].play){
          for(var xx=0; xx<game.players[order[game.dealer]].cards.length; xx++){
            if (game.players[order[game.dealer]].cards[xx] == game.players[order[game.dealer]].play){
              game.players[order[game.dealer]].cards[xx] = game.flip;
              game.players[order[game.dealer]].client.send(JSON.stringify({action: "getHandResult", cards: game.players[order[game.dealer]].cards}));
            }
          }
          break;
        } 
      }
      break;
    }
  }
  game.turn = game.dealer + 1;
  if (game.turn == 4){
    game.turn = 0;
  }
  for (var player of ["north", "south", "west", "east"]){
    game.players[player].client.send(JSON.stringify({action: "getTurnResult", turn: order[game.turn]}));
    game.players[player].play = null;
  } 
  if (!someoneCalled){
    var secondDone = false;
    for (var i=0; i<4; i++){
      for (var player of ["north", "south", "west", "east"]){
        game.players[player].client.send(JSON.stringify({action: "getTurnResult", turn: order[game.turn]}));
      } 
	  game.players[order[game.turn]].play = null;
      game.players[order[game.turn]].client.send(JSON.stringify({action: "pickTrump2", forced: i==3 ? true : false}));
      while (true){
        await sleep(300);
        if (game.players[order[game.turn]].play == "pass"){
          game.advanceTurn();
          break;
        }
        else if(game.players[order[game.turn]].play){
          game.trump = game.players[order[game.turn]].play;
          game.calledTrump = order[game.turn];
          for (var player of ["north", "south", "west", "east"]){
            game.players[player].client.send(JSON.stringify({action: "getTrumpResult", trump: game.trump, called: order[game.turn]}));
          }
          secondDone = true;
          break;
        }
      }
      if (secondDone){
        game.turn = game.dealer + 1;
        if (game.turn == 4){
          game.turn = 0;
        }
        break;
      }
    }
  }
  game.players[game.calledTrump].play = null;
  game.players[game.calledTrump].client.send(JSON.stringify({action: "goAlone"}));
  while (true){
	  await sleep(300);
	  if (game.players[game.calledTrump].play){
		  if (game.players[game.calledTrump].play == "yes"){
			game.players[teammates[game.calledTrump]].out = true;
			for (var player of ["north", "south", "west", "east"]){
				game.players[player].client.send(JSON.stringify({action: "goingAlone"}));
			}  
		  }
		  break;
	  }
  }
  for (var player of ["north", "south", "west", "east"]){
   // game.players[player].client.send(JSON.stringify({action: "getTrumpResult", trump: game.trump, called: order[game.turn]}));
    game.players[player].client.send(JSON.stringify({action: "getTurnResult", turn: order[game.turn]}));
    game.players[player].client.send(JSON.stringify({action: "roundStarted"}));
    game.players[player].play = null;
  }  
    for(var x=0; x<5; x++){
      for (var i=0; i<4; i++){
        while (true){
		  if (game.players[order[game.turn]].out){
			  break;
		  }
          await sleep(300);
          if (game.players[order[game.turn]].play){
            if (i == 0){
              var copyPlay = game.players[order[game.turn]].play;
              if (copyPlay.split("")[0] == "J" & copyPlay.split("")[1] == match[game.trump]){
                copyPlay = copyPlay.split("")[0] + game.trump;
              }
              game.lead = copyPlay.split("")[1];
            }
			if (!game.players[order[game.turn]].cards.includes(game.players[order[game.turn]].play)){
				game.players[order[game.turn]].play = null;
				game.players[order[game.turn]].client.send(JSON.stringify({action: "getHandResult", cards: game.players[order[game.turn]].cards}));
				continue;
			}
			for (var p=0; p<game.players[order[game.turn]].cards.length; p++){
				if (game.players[order[game.turn]].cards[p] == game.players[order[game.turn]].play){
					game.players[order[game.turn]].cards[p] = null;
					game.players[order[game.turn]].client.send(JSON.stringify({action: "getHandResult", cards: game.players[order[game.turn]].cards}));
					break;
				}
			}
            for (var player of ["north", "south", "west", "east"]){
              game.players[player].client.send(JSON.stringify({action: "cardPlayed", card: game.players[order[game.turn]].play, position: order[game.turn]}));
            } 
            break;
          }
        }
        game.advanceTurn();
        for (var player of ["north", "south", "west", "east"]){
          game.players[player].client.send(JSON.stringify({action: "getTurnResult", turn: order[game.turn]}));
        } 
      }
      await sleep(1000);
      var winningCards = ['J'+game.trump,'J'+match[game.trump], 'A'+game.trump, 'K'+game.trump, 'Q'+game.trump, 'T'+game.trump, 'N'+game.trump, 'A'+game.lead, 'K'+game.lead, 'Q'+game.lead, 'J'+game.lead, 'T'+game.lead, 'N'+game.lead];
      var winIndex = 1000;
      var win = null;
      for (var player of ["north", "south", "west", "east"]){
        for (var i=0; i<winningCards.length; i++){
          if (game.players[player].play == winningCards[i]){
            if (i < winIndex){
              win = player;
              winIndex = i;
              break;
            }
          }
        }
      }
      if (win == 'north' || win == 'south'){
        game.rScores.northsouth++;
      }
      else{
        game.rScores.eastwest++;
      }
      for (var z=0; z<order.length; z++){
        if (order[z] == win){
          game.turn = z;
        }
      }
      for (var player of ["north", "south", "west", "east"]){
        game.players[player].play = null;
        game.players[player].client.send(JSON.stringify({action: "getRoundResult", win: win}))
        game.players[player].client.send(JSON.stringify({action: "getTurnResult", turn: order[game.turn]}));
      } 
    }
    await sleep(1000);
    console.log('round ended')
    if (game.rScores.northsouth > game.rScores.eastwest){
      if (game.calledTrump == "north" || game.calledTrump == "south"){
        if (game.rScores.northsouth == 5){
			if (game.players.north.out || game.players.south.out){
				game.scores.northsouth+=4;
			}
			else{
				game.scores.northsouth+=2;
			}
        }
        else{
          game.scores.northsouth++;
        }
      }
      else{
          game.scores.northsouth+=2;
      }
    }
    else{
      if (game.calledTrump == "east" || game.calledTrump == "west"){
        if (game.rScores.eastwest == 5){
          if (game.players.east.out || game.players.west.out){
				game.scores.eastwest+=4;
			}
			else{
				game.scores.eastwest+=2;
			}
        }
        else{
          game.scores.eastwest++;
        }
      }
      else{
        game.scores.eastwest+=2;
      }
    }
    game.advanceDealer();
    for (var player of ["north", "south", "west", "east"]){
        game.players[player].play = null;
		game.players[player].out = false;
        game.players[player].client.send(JSON.stringify({action: "getMatchResult", northsouth: game.scores.northsouth, eastwest: game.scores.eastwest}));
    }
    game.trump = null;
    game.calledTrump = null;
    game.lead = null;
    game.rScores = {northsouth: 0, eastwest: 0}
    
  } 

  
  
 // game.players[game.dealer]
  
}
function sleep(ms){
  return new Promise(function(resolve, reject){
    setTimeout(resolve, ms);
  });
}


